/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tugaspolymorphism;

/**
 *
 * @author HP
 */
public class BukuDemo {
    public static void main(String[] args) {
        Buku buku1 = new Buku("Ips", "Pengarang Ips", "Penerbit Ips", 2023);
        Buku buku2 = new Buku("Ipa", "Pengarang Ipa");
    } 
}
